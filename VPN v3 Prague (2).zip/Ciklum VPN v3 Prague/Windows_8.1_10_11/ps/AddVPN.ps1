
function PrintError ($message) {
   Write-Host $message -ForegroundColor Red -BackgroundColor Black
}

function AddVPNConnection () {
  try {
    Add-VpnConnection -Name 'Ciklum VPN v3 Prague' -ServerAddress '194.213.195.150' -TunnelType 'IKEv2' -EncryptionLevel 'Required' -AuthenticationMethod Eap -SplitTunneling -RememberCredential 
    Set-VpnConnectionIPsecConfiguration -ConnectionName 'Ciklum VPN v3 Prague' -AuthenticationTransformConstants 'SHA256128' -CipherTransformConstants 'AES256' -DHGroup 'Group14' -EncryptionMethod 'AES256' -IntegrityCheckMethod 'SHA256' -PfsGroup 'PFS2048' -Force
    Add-VpnConnectionRoute -ConnectionName 'Ciklum VPN v3 Prague' -DestinationPrefix '192.168.0.0/16'
    Add-VpnConnectionRoute -ConnectionName 'Ciklum VPN v3 Prague' -DestinationPrefix '10.0.0.0/8'
    Add-VpnConnectionRoute -ConnectionName 'Ciklum VPN v3 Prague' -DestinationPrefix '172.16.0.0/12'
	Add-VpnConnectionRoute -ConnectionName 'Ciklum VPN v3 Prague' -DestinationPrefix '185.201.159.140/32'
    Write-Host "Created the 'Ciklum VPN v3 Prague' VPN connection"
  }   catch {
    PrintError "Error in creating the 'Ciklum VPN v3 Prague' VPN connection!" 
    PrintError $_.Exception.Message
  }
}

$vpn = Get-VpnConnection -Name 'Ciklum VPN v3 Prague' -ErrorAction SilentlyContinue
if ($vpn -and ($vpn.Name -eq 'Ciklum VPN v3 Prague')) {
  PrintError "A VPN connection with the name 'Ciklum VPN v3 Prague' is already configured on your system."
  $message = "Do you want to update the existing 'Ciklum VPN v3 Prague' VPN connection?"
  $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Updates the 'Ciklum VPN v3 Prague' VPN connection."
  $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Exit without updating."
  $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
  $result = $host.ui.PromptForChoice('', $message, $options, 0)
  switch ($result) {
    0 {Remove-VpnConnection -Name 'Ciklum VPN v3 Prague' -Force}
    1 {
      PrintError "The existing �Ciklum VPN v3 Prague� VPN connection was not updated. Remove or rename the existing VPN connection and run the script again.";
      exit
    }
  }
}

AddVPNConnection
exit

