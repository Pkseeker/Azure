Configure an IKEv2 VPN Connection to a WatchGuard Firebox in Android
====================================================================

To configure a VPN connection between your Android device and a Firebox, we recommend the free strongSwan client. Not all Android versions or devices natively support IKEv2 VPNs.

In the same folder as this README file, find the [filename].sswan file, which is a strongSwan profile. On your Android device, you can import this profile to automatically create a new IKEv2 VPN profile. This profile includes the required CA certificate.

You can also manually configure an IKEv2 VPN connection. This README file includes instructions for both automatic and manual configuration.

For operating system support information, see the Operating System Compatibility Matrix in the Fireware Release Notes at https://www.watchguard.com/wgrd-help/documentation/release-notes/fireware.

====================================================================
strongSwan Automatic Configuration

To automatically add a new IKEv2 VPN connection with the .sswan profile:

    1. Send the .sswan profile to your Android device. 
    2. On your Android device, save the .sswan profile.
    3. Download and install the strongSwan VPN client from the Google Play store.
    4. Open the strongSwan VPN client.
    5. Next to "Add VPN Profile," tap the three vertical dots.
    6. Tap "Import VPN profile."
    7. Tap "Files." 
    8. Tap the .sswan profile that you saved to your device. 
    9. Specify your username.
    10. (Optional) To save your password for later use, specify it now. 
    11. Tap "Import."
    12. To connect to the VPN, select the new IKEv2 profile that you added.
    
====================================================================
strongSwan Manual Configuration

To manually add a new IKEv2 VPN connection:

    1. Email the rootca.pem file to your Android device.
    2. In the email message, tap the attached rootca.pem file.
    3. Select "Import Certificate."
    4. Download and install the strongSwan VPN client from the Google Play store.
    5. Open the strongSwan VPN client.
    6. Select "Add VPN Profile."
    7. Specify this information:
        Server: 194.213.195.150
        VPN Type: "Firebox IKEv2 EAP (Username/Password)"
        Username: [Your Firebox username]
        Password: (Optional) To save your password for later use, specify it now.
        CA Certificate: "Select automatically"
        Profile Name: [Descriptive name such as "MyCompany IKEv2 VPN"]
    8. Click "Save." 
    9. To connect to the VPN, select the new IKEv2 profile that you added.

====================================================================
strongSwan DNS Configuration

The strongSwan client does not inherit a domain suffix or DNS servers from the Firebox. If the strongSwan client must resolve local FQDNs through the VPN, we recommend that you edit the strongSwan profile to add DNS servers. 

To manually add DNS servers to the strongSwan profile:

    1. Press and hold the .sswan profile that you imported to your Android device.
    2. Tap "Edit."
    3. Select the "Show Advanced Settings" check box.
    4. In the "DNS servers" text box, type the IP address of the local DNS server behind the Firebox.
    5. Tap "Save."

Note: For address resolution without a domain suffix, you must specify FQDNs and not host names.

====================================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
====================================================================