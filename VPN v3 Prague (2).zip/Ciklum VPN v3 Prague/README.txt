Configure an IKEv2 VPN Connection to a WatchGuard Firebox
=========================================================
You can use the files in this package to automatically create a new IKEv2 VPN profile on devices with supported versions of Windows, macOS, iOS, or Android. You can also manually configure an IKEv2 VPN profile on your device. If you manually configure a VPN profile, you must install the rootca.pem or rootca.crt certificate included in the same folder as this README file.

For configuration instructions specific to your operating system, see the README.txt files in these folders:
* Windows_8.1_10_11
* MacOS_iOS
* Android

For operating system support information, see the Operating System Compatibility Matrix in the Fireware Release Notes at https://www.watchguard.com/wgrd-help/documentation/release-notes/fireware.

For online versions of IKEv2 VPN client configuration instructions, see these topics in Fireware Help:

Windows 8.1, Windows 10 and Windows 11:
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_windows_client.html

macOS and iOS: 
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_mac_client.html

Android (with the strongSwan app): 
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_android_client.html

=========================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
=========================================================
